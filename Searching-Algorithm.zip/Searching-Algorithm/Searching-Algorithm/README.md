# Searching-Algorithm

Searching Algorithms--linear search,Binary Search,Ternary Search
